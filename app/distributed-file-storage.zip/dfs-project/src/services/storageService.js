const { v4: uuidv4 } = require("uuid");
const { Upload } = require("@aws-sdk/lib-storage");
const {
  GetObjectCommand,
  DeleteObjectCommand,
} = require("@aws-sdk/client-s3");
const { s3Client, S3_BUCKET_NAME } = require("../config/aws");
const { gcsBucket } = require("../config/gcs");
const dynamoService = require("./dynamoService");

/**
 * Upload a file to S3 (primary) AND replicate it to Google Cloud Storage (backup).
 * Local disk is never touched — everything is streamed from memory (multer buffer).
 * If GCS replication fails, we still keep the file (S3 succeeded) but mark it
 * as "not replicated" in metadata so a background job could retry later.
 */
async function uploadFile({ buffer, originalName, mimeType, size }) {
  const fileId = uuidv4();
  const objectKey = `${fileId}/${originalName}`;

  let s3Status = "failed";
  let gcsStatus = "failed";

  // ---- 1. Upload to AWS S3 (primary) ----
  try {
    const s3Upload = new Upload({
      client: s3Client,
      params: {
        Bucket: S3_BUCKET_NAME,
        Key: objectKey,
        Body: buffer,
        ContentType: mimeType,
      },
    });
    await s3Upload.done();
    s3Status = "ok";
  } catch (err) {
    console.error(`[storageService] S3 upload failed for ${fileId}:`, err.message);
  }

  // ---- 2. Replicate to Google Cloud Storage (backup) ----
  try {
    const gcsFile = gcsBucket.file(objectKey);
    await gcsFile.save(buffer, {
      contentType: mimeType,
      resumable: false,
    });
    gcsStatus = "ok";
  } catch (err) {
    console.error(`[storageService] GCS replication failed for ${fileId}:`, err.message);
  }

  if (s3Status === "failed" && gcsStatus === "failed") {
    throw new Error("Upload failed on both AWS S3 and Google Cloud Storage");
  }

  const metadata = {
    fileId,
    originalName,
    mimeType,
    size,
    objectKey,
    s3Status,
    gcsStatus,
    status: "active",
    uploadedAt: new Date().toISOString(),
  };

  await dynamoService.saveFileMetadata(metadata);
  return metadata;
}

/**
 * Download a file. Tries S3 first (primary); if that fails for any reason
 * (server down, network issue, object missing) it automatically falls back
 * to Google Cloud Storage. This is the "agar ek cloud down ho toh dusra chale" logic.
 */
async function downloadFile(fileId) {
  const metadata = await dynamoService.getFileMetadata(fileId);
  if (!metadata || metadata.status !== "active") {
    return null;
  }

  // Try S3 first
  if (metadata.s3Status === "ok") {
    try {
      const result = await s3Client.send(
        new GetObjectCommand({ Bucket: S3_BUCKET_NAME, Key: metadata.objectKey })
      );
      const buffer = await streamToBuffer(result.Body);
      return { buffer, metadata, servedFrom: "s3" };
    } catch (err) {
      console.warn(`[storageService] S3 download failed for ${fileId}, falling back to GCS:`, err.message);
    }
  }

  // Fallback to GCS
  if (metadata.gcsStatus === "ok") {
    try {
      const [buffer] = await gcsBucket.file(metadata.objectKey).download();
      return { buffer, metadata, servedFrom: "gcs" };
    } catch (err) {
      console.error(`[storageService] GCS download also failed for ${fileId}:`, err.message);
    }
  }

  throw new Error("File could not be retrieved from either S3 or GCS");
}

/**
 * Delete file from both clouds (best-effort) and mark metadata as deleted.
 */
async function deleteFile(fileId) {
  const metadata = await dynamoService.getFileMetadata(fileId);
  if (!metadata) return false;

  try {
    await s3Client.send(
      new DeleteObjectCommand({ Bucket: S3_BUCKET_NAME, Key: metadata.objectKey })
    );
  } catch (err) {
    console.error(`[storageService] S3 delete failed for ${fileId}:`, err.message);
  }

  try {
    await gcsBucket.file(metadata.objectKey).delete({ ignoreNotFound: true });
  } catch (err) {
    console.error(`[storageService] GCS delete failed for ${fileId}:`, err.message);
  }

  await dynamoService.deleteFileMetadata(fileId);
  return true;
}

function streamToBuffer(stream) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    stream.on("data", (chunk) => chunks.push(chunk));
    stream.on("error", reject);
    stream.on("end", () => resolve(Buffer.concat(chunks)));
  });
}

module.exports = { uploadFile, downloadFile, deleteFile };
