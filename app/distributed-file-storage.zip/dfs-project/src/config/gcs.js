const { Storage } = require("@google-cloud/storage");

// Google Cloud Storage -> used as a REPLICA / backup of every file.
// Agar AWS S3 down ho ya S3 se download fail ho jaye, hum GCS se serve kar dete hain.
const gcsStorage = new Storage({
  projectId: process.env.GCS_PROJECT_ID,
  keyFilename: process.env.GCS_KEY_FILE, // path to service-account.json
});

const gcsBucket = gcsStorage.bucket(process.env.GCS_BUCKET_NAME);

module.exports = { gcsStorage, gcsBucket };
