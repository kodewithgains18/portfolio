# Distributed File Storage System

Local disk pe kuch save nahi hota — sab kuch memory se seedha cloud jaata hai.

## Architecture

```
                        ┌─────────────┐
        Client  ───────▶│    Nginx    │  (load balancer + health checks)
                        └──────┬──────┘
                 ┌─────────────┼─────────────┐
                 ▼             ▼             ▼
             ┌───────┐    ┌───────┐    ┌───────┐
             │ app1  │    │ app2  │    │ app3  │   (identical Node.js instances)
             └───┬───┘    └───┬───┘    └───┬───┘
                 └─────────────┼─────────────┘
                       ┌───────┴────────┐
                       ▼                ▼
                ┌─────────────┐  ┌──────────────┐
                │   AWS S3    │  │  Google Cloud │
                │  (primary)  │  │Storage(replica)│
                └─────────────┘  └──────────────┘
                       │
                       ▼
                ┌─────────────┐
                │  DynamoDB   │  (file metadata)
                └─────────────┘
```

- **Har file S3 + GCS dono me save hoti hai.** Agar upload ke time ek cloud fail ho, doosra bhi ho toh file safe rehti hai; status (`s3Status`/`gcsStatus`) DynamoDB me store hota hai.
- **Download ke time S3 try hota hai pehle**, agar woh fail ho jaye (down/network issue) toh automatically GCS se serve hota hai — code khud fallback karta hai.
- **3 identical app servers** run hote hain. Nginx unke aage baitha hai. Agar `app1` crash ho jaye, nginx use "down" mark karke turant `app2`/`app3` pe traffic bhej deta hai — no downtime.

## 1. AWS Setup (Free Tier)

1. AWS account banao (free tier eligible).
2. **S3**: Console → S3 → Create bucket → globally unique name (e.g. `my-dfs-bucket-2026`). Public access block ON rakho (default).
3. **IAM**: ek IAM user banao with programmatic access, attach policy: `AmazonS3FullAccess` + `AmazonDynamoDBFullAccess` (production me scope-down karna better hai). Access Key ID + Secret Access Key copy kar lo.
4. **DynamoDB**: table khud script se ban jayega (`npm run create-table`) — `PAY_PER_REQUEST` mode use kiya hai jo free tier ke liye best hai (koi fixed capacity provision nahi karni padti).

## 2. Google Cloud Setup

1. GCP project banao, billing account link karo (free tier/trial credits milte hain).
2. **Cloud Storage** → bucket banao (globally unique name).
3. **Service Account**: IAM & Admin → Service Accounts → new service account → role `Storage Object Admin` → key create karo (JSON) → download karke `secrets/gcs-service-account.json` me rakho.

## 3. Configure

```bash
cp .env.example .env
# .env file me apne AWS keys, bucket names, GCS project id, etc fill karo
mkdir -p secrets
# gcs-service-account.json ko secrets/ folder me daalo
```

## 4. Create the DynamoDB table (one-time)

```bash
npm install
npm run create-table
```

## 5. Run locally (single instance, for testing)

```bash
npm start
# server http://localhost:3000 pe chalega
```

## 6. Run distributed (3 servers + Nginx load balancer)

```bash
docker compose up --build
```

Ab `http://localhost` (port 80) pe requests jayengi, Nginx unhe teeno app instances me baant dega.

### Test failover

```bash
docker compose stop app1        # simulate crash
curl http://localhost/api/files # still works — app2/app3 serve karte hain
docker compose start app1       # nginx apne aap use wapas pool me le lega
```

## API Endpoints

| Method | Endpoint                     | Description                          |
|--------|-------------------------------|---------------------------------------|
| POST   | `/api/files/upload`          | multipart form field `file`          |
| GET    | `/api/files`                 | list files (paginated, `?limit=&cursor=`) |
| GET    | `/api/files/:fileId`         | get metadata                         |
| GET    | `/api/files/:fileId/download`| download (auto-fallback S3 → GCS)    |
| DELETE | `/api/files/:fileId`         | delete from both clouds + metadata   |
| GET    | `/health`                    | health check (used by Nginx)         |

### Example: upload

```bash
curl -F "file=@/path/to/photo.jpg" http://localhost/api/files/upload
```

### Example: download

```bash
curl -OJ http://localhost/api/files/<fileId>/download
```

## Notes / Free-tier considerations

- S3 free tier: 5GB storage, 20k GET / 2k PUT requests per month (first 12 months).
- DynamoDB free tier: 25GB storage + 25 WCU/RCU always free (`PAY_PER_REQUEST` billing keeps this comfortably within limits for low traffic).
- GCS: check current free trial credits — after trial, storage is billed per GB; monitor usage.
- `MAX_FILE_SIZE_MB` env var + Nginx `client_max_body_size` — dono ko sync me rakho.
