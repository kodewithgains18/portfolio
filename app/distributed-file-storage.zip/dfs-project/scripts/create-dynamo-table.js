require("dotenv").config();
const { DynamoDBClient, CreateTableCommand, waitUntilTableExists } = require("@aws-sdk/client-dynamodb");

const client = new DynamoDBClient({
  region: process.env.AWS_REGION || "ap-south-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const TableName = process.env.DYNAMODB_TABLE_NAME || "DFS_Files";

async function main() {
  try {
    console.log(`Creating DynamoDB table "${TableName}" (PAY_PER_REQUEST -> free tier friendly)...`);
    await client.send(
      new CreateTableCommand({
        TableName,
        AttributeDefinitions: [{ AttributeName: "fileId", AttributeType: "S" }],
        KeySchema: [{ AttributeName: "fileId", KeyType: "HASH" }],
        BillingMode: "PAY_PER_REQUEST", // no provisioned capacity to manage, free tier covers 25 RCU/WCU equivalent usage
      })
    );
    await waitUntilTableExists({ client, maxWaitTime: 60 }, { TableName });
    console.log("Table created and active.");
  } catch (err) {
    if (err.name === "ResourceInUseException") {
      console.log("Table already exists, skipping.");
    } else {
      console.error("Failed to create table:", err.message);
      process.exit(1);
    }
  }
}

main();
