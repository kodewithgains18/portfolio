require("dotenv").config();
const { DynamoDBClient, CreateTableCommand, waitUntilTableExists } = require("@aws-sdk/client-dynamodb");

// Points at the LOCAL DynamoDB container -> no AWS account needed, no billing.
const client = new DynamoDBClient({
  region: "us-east-1",
  endpoint: process.env.DYNAMODB_ENDPOINT || "http://localhost:8000",
  credentials: {
    accessKeyId: process.env.MINIO_ACCESS_KEY || "minioadmin",
    secretAccessKey: process.env.MINIO_SECRET_KEY || "minioadmin",
  },
});

const TableName = process.env.DYNAMODB_TABLE_NAME || "DFS_Files";

async function main() {
  try {
    console.log(`Creating table "${TableName}" on local DynamoDB...`);
    await client.send(
      new CreateTableCommand({
        TableName,
        AttributeDefinitions: [{ AttributeName: "fileId", AttributeType: "S" }],
        KeySchema: [{ AttributeName: "fileId", KeyType: "HASH" }],
        BillingMode: "PAY_PER_REQUEST",
      })
    );
    await waitUntilTableExists({ client, maxWaitTime: 60 }, { TableName });
    console.log("Table created and active.");
  } catch (err) {
    if (err.name === "ResourceInUseException") {
      console.log("Table already exists, skipping.");
    } else {
      console.error("Failed to create table:", err.message);
      process.exit(1);
    }
  }
}

main();
