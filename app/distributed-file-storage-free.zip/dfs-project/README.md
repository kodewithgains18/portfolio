# Distributed File Storage System (100% Free, No Cloud Account Needed)

Local disk pe file save nahi hoti — sab kuch memory se seedha storage containers me jaata hai.
Koi AWS account nahi, koi GCP account nahi, koi credit card nahi. Sab kuch aapke apne
computer/server par Docker ke andar chalta hai, permanently free.

## Architecture

```
                        ┌─────────────┐
        Client  ───────▶│    Nginx    │  (load balancer + health checks)
                        └──────┬──────┘
                 ┌─────────────┼─────────────┐
                 ▼             ▼             ▼
             ┌───────┐    ┌───────┐    ┌───────┐
             │ app1  │    │ app2  │    │ app3  │   (identical Node.js instances)
             └───┬───┘    └───┬───┘    └───┬───┘
                 └─────────────┼─────────────┘
                       ┌───────┴────────┐
                       ▼                ▼
                ┌─────────────┐  ┌──────────────┐
                │MinIO primary│  │ MinIO replica│   (self-hosted, S3-compatible)
                └─────────────┘  └──────────────┘
                       │
                       ▼
                ┌─────────────┐
                │DynamoDB Local│  (self-hosted metadata store)
                └─────────────┘
```

- **Har file dono MinIO containers me save hoti hai** (primary + replica). Agar ek container/disk crash ho jaaye, file doosre se serve ho jaati hai — code automatically fallback karta hai.
- **3 identical app servers.** Nginx unke aage baitha hai. Agar `app1` crash ho jaaye, Nginx use turant "down" mark karke `app2`/`app3` pe traffic bhej deta hai — no downtime.
- **MinIO** = open-source, S3-compatible object storage. **DynamoDB Local** = Amazon ka hi official local version of DynamoDB, sirf testing/self-hosting ke liye — same API, zero cost, no AWS account.

## Requirements

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed — bas itna hi chahiye. Koi cloud account nahi.

## 1. Setup

```bash
cd dfs-project
cp .env.example .env       # defaults already work out of the box, kuch change karne ki zaroorat nahi
```

## 2. Sab kuch ek command se start karo

```bash
docker compose up --build
```

Yeh automatically start karega:
- 2x MinIO containers (primary + replica)
- 1x DynamoDB Local container
- 3x app server instances
- 1x Nginx load balancer (port 80 pe)

Pehli baar app start hote waqt khud hi buckets create kar lega (`ensureBucketsExist`), koi manual step nahi.

## 3. DynamoDB table banao (one-time, sirf pehli baar)

Naya terminal kholo (compose already chal raha ho tab):

```bash
npm install
npm run create-table
```

(Yeh apke computer se local container ko hit karta hai — `.env` me `DYNAMODB_ENDPOINT=http://localhost:8000` set karke local run ke liye use kar sakte ho, ya seedha `docker compose exec app1 npm run create-table` bhi chala sakte ho.)

## 4. Test karo

```bash
curl -F "file=@/path/to/photo.jpg" http://localhost/api/files/upload
curl http://localhost/api/files
curl -OJ http://localhost/api/files/<fileId>/download
```

## 5. Failover test karo

```bash
docker compose stop app1              # app server crash simulate
curl http://localhost/api/files       # phir bhi kaam karega — app2/app3 serve karte hain

docker compose stop minio-primary     # storage crash simulate
curl -OJ http://localhost/api/files/<fileId>/download   # replica se serve hoga
```

## API Endpoints

| Method | Endpoint                      | Description                              |
|--------|--------------------------------|-------------------------------------------|
| POST   | `/api/files/upload`           | multipart form field `file`               |
| GET    | `/api/files`                  | list files (paginated, `?limit=&cursor=`) |
| GET    | `/api/files/:fileId`          | get metadata                              |
| GET    | `/api/files/:fileId/download` | download (auto-fallback primary → replica)|
| DELETE | `/api/files/:fileId`          | delete from both storage + metadata       |
| GET    | `/health`                     | health check (used by Nginx)              |

## Storage location on your machine

Files Docker **named volumes** me store hote hain (`minio_primary_data`, `minio_replica_data`, `dynamo_data`) — yeh app ke apne container filesystem se bahar, Docker ke manage kiye hue persistent volumes hain, jo restart ke baad bhi data rakhte hain.

```bash
docker compose down          # containers ruk jaate hain, data safe rehta hai
docker compose down -v       # containers + saara data delete (careful!)
```

## Agla step (optional, future)

Agar aage chal ke real cloud pe deploy karna ho (jab traffic badhe), same code AWS S3 +
DynamoDB ke saath bhi kaam karega — bas `.env` me endpoints hata kar real AWS credentials
aur bucket names daal dena, code same rahega (MinIO S3 API-compatible hai).
