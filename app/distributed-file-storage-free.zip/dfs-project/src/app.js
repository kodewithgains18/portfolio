require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const fileRoutes = require("./routes/fileRoutes");

const app = express();

app.use(helmet());
app.use(cors());
app.use(morgan("combined"));

// Health check -> Nginx / any load balancer pings this to decide if the
// server instance is alive. Agar yeh fail ho, LB traffic doosre server pe bhej dega.
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "ok",
    server: process.env.SERVER_ID || "unknown",
    timestamp: new Date().toISOString(),
  });
});

app.use("/api/files", fileRoutes);

app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});

// Central error handler (e.g. multer file-too-large errors)
app.use((err, req, res, next) => {
  console.error("[unhandled error]", err.message);
  res.status(500).json({ error: "Internal server error", details: err.message });
});

module.exports = app;
