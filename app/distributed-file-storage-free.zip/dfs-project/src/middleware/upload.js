const multer = require("multer");

// Memory storage -> file buffer sirf RAM me rehta hai, kabhi bhi local disk pe
// save nahi hota. Seedha S3/GCS ko stream kiya jaata hai.
const maxSizeMb = Number(process.env.MAX_FILE_SIZE_MB || 50);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: maxSizeMb * 1024 * 1024 },
});

module.exports = upload;
