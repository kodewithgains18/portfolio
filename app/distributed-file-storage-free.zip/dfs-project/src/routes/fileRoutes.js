const express = require("express");
const upload = require("../middleware/upload");
const storageService = require("../services/storageService");
const dynamoService = require("../services/dynamoService");

const router = express.Router();

// ---- Upload a file ----
router.post("/upload", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file provided (field name should be 'file')" });
    }

    const metadata = await storageService.uploadFile({
      buffer: req.file.buffer,
      originalName: req.file.originalname,
      mimeType: req.file.mimetype,
      size: req.file.size,
    });

    res.status(201).json({ message: "File uploaded", file: metadata });
  } catch (err) {
    console.error("[upload] error:", err.message);
    res.status(500).json({ error: "Upload failed", details: err.message });
  }
});

// ---- List files (paginated) ----
router.get("/", async (req, res) => {
  try {
    const limit = req.query.limit ? Number(req.query.limit) : 50;
    const lastEvaluatedKey = req.query.cursor
      ? JSON.parse(Buffer.from(req.query.cursor, "base64").toString())
      : undefined;

    const { items, lastEvaluatedKey: nextKey } = await dynamoService.listFiles({
      limit,
      lastEvaluatedKey,
    });

    res.json({
      files: items,
      nextCursor: nextKey
        ? Buffer.from(JSON.stringify(nextKey)).toString("base64")
        : null,
    });
  } catch (err) {
    console.error("[list] error:", err.message);
    res.status(500).json({ error: "Could not list files", details: err.message });
  }
});

// ---- Get metadata for one file ----
router.get("/:fileId", async (req, res) => {
  try {
    const metadata = await dynamoService.getFileMetadata(req.params.fileId);
    if (!metadata || metadata.status !== "active") {
      return res.status(404).json({ error: "File not found" });
    }
    res.json({ file: metadata });
  } catch (err) {
    res.status(500).json({ error: "Could not fetch metadata", details: err.message });
  }
});

// ---- Download a file ----
router.get("/:fileId/download", async (req, res) => {
  try {
    const result = await storageService.downloadFile(req.params.fileId);
    if (!result) {
      return res.status(404).json({ error: "File not found" });
    }

    res.set({
      "Content-Type": result.metadata.mimeType || "application/octet-stream",
      "Content-Disposition": `attachment; filename="${result.metadata.originalName}"`,
      "X-Served-From": result.servedFrom, // 's3' or 'gcs' -> useful for debugging failover
    });
    res.send(result.buffer);
  } catch (err) {
    console.error("[download] error:", err.message);
    res.status(500).json({ error: "Download failed", details: err.message });
  }
});

// ---- Delete a file ----
router.delete("/:fileId", async (req, res) => {
  try {
    const deleted = await storageService.deleteFile(req.params.fileId);
    if (!deleted) {
      return res.status(404).json({ error: "File not found" });
    }
    res.json({ message: "File deleted" });
  } catch (err) {
    console.error("[delete] error:", err.message);
    res.status(500).json({ error: "Delete failed", details: err.message });
  }
});

module.exports = router;
