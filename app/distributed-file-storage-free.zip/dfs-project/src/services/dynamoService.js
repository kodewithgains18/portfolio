const {
  PutCommand,
  GetCommand,
  DeleteCommand,
  ScanCommand,
} = require("@aws-sdk/lib-dynamodb");
const { dynamoDocClient, DYNAMODB_TABLE_NAME } = require("../config/storage");

/**
 * Save file metadata after a successful (or partially successful) upload.
 * Item shape:
 * {
 *   fileId, originalName, mimeType, size,
 *   s3Key, s3Status ('ok' | 'failed'),
 *   gcsKey, gcsStatus ('ok' | 'failed' | 'skipped'),
 *   status ('active' | 'deleted'),
 *   uploadedAt
 * }
 */
async function saveFileMetadata(item) {
  await dynamoDocClient.send(
    new PutCommand({
      TableName: DYNAMODB_TABLE_NAME,
      Item: item,
    })
  );
  return item;
}

async function getFileMetadata(fileId) {
  const result = await dynamoDocClient.send(
    new GetCommand({
      TableName: DYNAMODB_TABLE_NAME,
      Key: { fileId },
    })
  );
  return result.Item || null;
}

async function deleteFileMetadata(fileId) {
  await dynamoDocClient.send(
    new DeleteCommand({
      TableName: DYNAMODB_TABLE_NAME,
      Key: { fileId },
    })
  );
}

/**
 * Simple listing (fine for free-tier / low volume use).
 * For production scale, replace Scan with a Query on a GSI.
 */
async function listFiles({ limit = 50, lastEvaluatedKey } = {}) {
  const result = await dynamoDocClient.send(
    new ScanCommand({
      TableName: DYNAMODB_TABLE_NAME,
      Limit: limit,
      ExclusiveStartKey: lastEvaluatedKey,
      FilterExpression: "#status = :active",
      ExpressionAttributeNames: { "#status": "status" },
      ExpressionAttributeValues: { ":active": "active" },
    })
  );
  return {
    items: result.Items || [],
    lastEvaluatedKey: result.LastEvaluatedKey || null,
  };
}

module.exports = {
  saveFileMetadata,
  getFileMetadata,
  deleteFileMetadata,
  listFiles,
};
