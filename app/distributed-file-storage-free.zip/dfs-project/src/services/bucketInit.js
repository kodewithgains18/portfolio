const { CreateBucketCommand, HeadBucketCommand } = require("@aws-sdk/client-s3");
const {
  s3PrimaryClient,
  s3ReplicaClient,
  PRIMARY_BUCKET,
  REPLICA_BUCKET,
} = require("../config/storage");

async function ensureBucket(client, bucketName) {
  try {
    await client.send(new HeadBucketCommand({ Bucket: bucketName }));
  } catch (err) {
    // Bucket doesn't exist -> create it
    await client.send(new CreateBucketCommand({ Bucket: bucketName }));
    console.log(`Bucket "${bucketName}" created.`);
  }
}

async function ensureBucketsExist() {
  await ensureBucket(s3PrimaryClient, PRIMARY_BUCKET);
  await ensureBucket(s3ReplicaClient, REPLICA_BUCKET);
}

module.exports = { ensureBucketsExist };
