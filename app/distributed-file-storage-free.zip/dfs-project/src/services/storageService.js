const { v4: uuidv4 } = require("uuid");
const { Upload } = require("@aws-sdk/lib-storage");
const {
  GetObjectCommand,
  DeleteObjectCommand,
} = require("@aws-sdk/client-s3");
const {
  s3PrimaryClient,
  s3ReplicaClient,
  PRIMARY_BUCKET,
  REPLICA_BUCKET,
} = require("../config/storage");
const dynamoService = require("./dynamoService");

async function uploadFile({ buffer, originalName, mimeType, size }) {
  const fileId = uuidv4();
  const objectKey = `${fileId}/${originalName}`;

  let primaryStatus = "failed";
  let replicaStatus = "failed";

  try {
    const primaryUpload = new Upload({
      client: s3PrimaryClient,
      params: { Bucket: PRIMARY_BUCKET, Key: objectKey, Body: buffer, ContentType: mimeType },
    });
    await primaryUpload.done();
    primaryStatus = "ok";
  } catch (err) {
    console.error(`[storageService] primary upload failed for ${fileId}:`, err.message);
  }

  try {
    const replicaUpload = new Upload({
      client: s3ReplicaClient,
      params: { Bucket: REPLICA_BUCKET, Key: objectKey, Body: buffer, ContentType: mimeType },
    });
    await replicaUpload.done();
    replicaStatus = "ok";
  } catch (err) {
    console.error(`[storageService] replica upload failed for ${fileId}:`, err.message);
  }

  if (primaryStatus === "failed" && replicaStatus === "failed") {
    throw new Error("Upload failed on both primary and replica storage");
  }

  const metadata = {
    fileId,
    originalName,
    mimeType,
    size,
    objectKey,
    primaryStatus,
    replicaStatus,
    status: "active",
    uploadedAt: new Date().toISOString(),
  };

  await dynamoService.saveFileMetadata(metadata);
  return metadata;
}

async function downloadFile(fileId) {
  const metadata = await dynamoService.getFileMetadata(fileId);
  if (!metadata || metadata.status !== "active") {
    return null;
  }

  if (metadata.primaryStatus === "ok") {
    try {
      const result = await s3PrimaryClient.send(
        new GetObjectCommand({ Bucket: PRIMARY_BUCKET, Key: metadata.objectKey })
      );
      const buffer = await streamToBuffer(result.Body);
      return { buffer, metadata, servedFrom: "primary" };
    } catch (err) {
      console.warn(`[storageService] primary download failed for ${fileId}, falling back to replica:`, err.message);
    }
  }

  if (metadata.replicaStatus === "ok") {
    try {
      const result = await s3ReplicaClient.send(
        new GetObjectCommand({ Bucket: REPLICA_BUCKET, Key: metadata.objectKey })
      );
      const buffer = await streamToBuffer(result.Body);
      return { buffer, metadata, servedFrom: "replica" };
    } catch (err) {
      console.error(`[storageService] replica download also failed for ${fileId}:`, err.message);
    }
  }

  throw new Error("File could not be retrieved from either primary or replica storage");
}

async function deleteFile(fileId) {
  const metadata = await dynamoService.getFileMetadata(fileId);
  if (!metadata) return false;

  try {
    await s3PrimaryClient.send(new DeleteObjectCommand({ Bucket: PRIMARY_BUCKET, Key: metadata.objectKey }));
  } catch (err) {
    console.error(`[storageService] primary delete failed for ${fileId}:`, err.message);
  }

  try {
    await s3ReplicaClient.send(new DeleteObjectCommand({ Bucket: REPLICA_BUCKET, Key: metadata.objectKey }));
  } catch (err) {
    console.error(`[storageService] replica delete failed for ${fileId}:`, err.message);
  }

  await dynamoService.deleteFileMetadata(fileId);
  return true;
}

function streamToBuffer(stream) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    stream.on("data", (chunk) => chunks.push(chunk));
    stream.on("error", reject);
    stream.on("end", () => resolve(Buffer.concat(chunks)));
  });
}

module.exports = { uploadFile, downloadFile, deleteFile };
