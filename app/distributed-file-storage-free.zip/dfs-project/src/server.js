const app = require("./app");
const { ensureBucketsExist } = require("./services/bucketInit");

const PORT = process.env.PORT || 3000;
const SERVER_ID = process.env.SERVER_ID || "unknown";

async function start() {
  // Wait for MinIO containers to be reachable and create buckets if needed.
  let retries = 10;
  while (retries > 0) {
    try {
      await ensureBucketsExist();
      break;
    } catch (err) {
      retries -= 1;
      console.log(`[${SERVER_ID}] Waiting for MinIO to be ready... (${retries} retries left)`);
      await new Promise((r) => setTimeout(r, 3000));
    }
  }

  app.listen(PORT, () => {
    console.log(`[${SERVER_ID}] Distributed File Storage API running on port ${PORT}`);
  });
}

start();
