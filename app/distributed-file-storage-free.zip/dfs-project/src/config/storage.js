const { S3Client } = require("@aws-sdk/client-s3");
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient } = require("@aws-sdk/lib-dynamodb");

// ---------------------------------------------------------------------------
// Everything below talks to SELF-HOSTED, FREE services running in Docker:
//   - MinIO (S3-compatible object storage) x2  -> primary + replica
//   - DynamoDB Local (same API as real DynamoDB) -> metadata store
// No AWS/GCP account, no credit card, no billing risk. Same AWS SDK is used
// because MinIO and DynamoDB Local both implement the real AWS APIs.
// ---------------------------------------------------------------------------

const dummyCreds = {
  accessKeyId: process.env.MINIO_ACCESS_KEY || "minioadmin",
  secretAccessKey: process.env.MINIO_SECRET_KEY || "minioadmin",
};

// Primary object storage
const s3PrimaryClient = new S3Client({
  region: "us-east-1", // required by SDK, meaningless for MinIO
  endpoint: process.env.MINIO_PRIMARY_ENDPOINT || "http://minio-primary:9000",
  forcePathStyle: true, // required for MinIO
  credentials: dummyCreds,
});

// Replica object storage (separate container -> if primary container/disk dies,
// files are still safely served from here)
const s3ReplicaClient = new S3Client({
  region: "us-east-1",
  endpoint: process.env.MINIO_REPLICA_ENDPOINT || "http://minio-replica:9000",
  forcePathStyle: true,
  credentials: dummyCreds,
});

// Metadata store (DynamoDB Local -> free, runs in its own container)
const dynamoClient = new DynamoDBClient({
  region: "us-east-1",
  endpoint: process.env.DYNAMODB_ENDPOINT || "http://dynamodb-local:8000",
  credentials: dummyCreds,
});

const dynamoDocClient = DynamoDBDocumentClient.from(dynamoClient, {
  marshallOptions: { removeUndefinedValues: true },
});

module.exports = {
  s3PrimaryClient,
  s3ReplicaClient,
  dynamoDocClient,
  PRIMARY_BUCKET: process.env.PRIMARY_BUCKET_NAME || "dfs-primary",
  REPLICA_BUCKET: process.env.REPLICA_BUCKET_NAME || "dfs-replica",
  DYNAMODB_TABLE_NAME: process.env.DYNAMODB_TABLE_NAME || "DFS_Files",
};
